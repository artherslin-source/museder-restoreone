<?php
/**
 * Museder Blank Theme functions and definitions
 *
 * @package Museder_Blank_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme setup function
 */
function museder_blank_setup() {
	// Enable title tag support
	add_theme_support( 'title-tag' );

	// Enable post thumbnails
	add_theme_support( 'post-thumbnails' );

	// Enable HTML5 support
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );
}
add_action( 'after_setup_theme', 'museder_blank_setup' );

/**
 * Enqueue scripts and styles
 */
function museder_blank_enqueue_scripts() {
	wp_enqueue_style(
		'museder-blank-style',
		get_stylesheet_uri(),
		array(),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'museder_blank_enqueue_scripts' );

