<?php
/**
 * The main template file
 *
 * @package Museder_Blank_Theme
 */

get_header();
?>

<main id="primary" class="site-main">
	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			?>
			<article>
				<h2><?php the_title(); ?></h2>
				<?php the_content(); ?>
			</article>
			<?php
		endwhile;
	else :
		?>
		<p>目前還沒有內容</p>
		<?php
	endif;
	?>
</main>

<?php
get_footer();

