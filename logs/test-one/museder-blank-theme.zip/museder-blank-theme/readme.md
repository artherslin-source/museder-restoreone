# Museder Blank Theme

這是一個極簡的 WordPress 空白起始主題，只包含最基本的檔案與結構，用來當作自訂開發用的底板。

## 功能

- 基本的 WordPress 主題結構
- 支援 title-tag
- 支援文章縮圖（post-thumbnails）
- HTML5 支援
- 基本的 404 錯誤頁面

## 啟用方式

1. 將整個 `museder-blank-theme` 資料夾上傳到 WordPress 安裝目錄的 `/wp-content/themes/` 下
2. 登入 WordPress 後台
3. 前往「外觀」>「主題」
4. 找到「Museder Blank Theme」並點擊「啟用」

## 檔案結構

- `style.css` - 主題樣式表（包含主題資訊）
- `functions.php` - 主題功能設定
- `header.php` - 頁首模板
- `footer.php` - 頁尾模板
- `index.php` - 主模板檔案
- `404.php` - 404 錯誤頁面模板

## 開發說明

此主題為空白起始主題，所有 UI 設計與功能都需要自行開發。所有函式與變數都使用 `museder_blank_` 前綴以避免命名衝突。

