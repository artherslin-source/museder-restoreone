<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Museder_Blank_Theme
 */

get_header();
?>

<main id="primary" class="site-main">
	<h1>404 – 找不到內容</h1>
	<p>抱歉，您要尋找的頁面不存在。</p>
</main>

<?php
get_footer();

