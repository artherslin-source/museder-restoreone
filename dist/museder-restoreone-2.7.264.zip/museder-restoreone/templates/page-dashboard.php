<?php
/**
 * Backup Lite dashboard page.
 *
 * @package BackupLite
 *
 * Template context variables.
 *
 * Variables in this file are provided by the plugin when loading the view
 * and are not registered as global variables.
 *
 * @phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Template context: These variables are scoped to this template file and provided by the rendering function.
// They use short names for template readability but are not global namespace pollution.
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
$status                   = isset( $status ) ? $status : Museder_Restoreone_UI::get_environment_status();
$dashboard_recent_backups = isset( $dashboard_recent_backups ) ? $dashboard_recent_backups : Museder_Restoreone_Dashboard::get_recent_backups( 3 );
$schedule_overview        = isset( $schedule_overview ) ? $schedule_overview : Museder_Restoreone_Dashboard::get_schedule_overview();
$activity_stats           = isset( $activity_stats ) ? $activity_stats : Museder_Restoreone_Dashboard::get_activity_stats();
$recent_logs              = isset( $recent_logs ) ? $recent_logs : Museder_Restoreone_Log_Handler::get_logs( 3 );

$chart_success = isset( $activity_stats['success'] ) ? (int) $activity_stats['success'] : 0;
$chart_failed  = isset( $activity_stats['failed'] ) ? (int) $activity_stats['failed'] : 0;

// Check if safe mode is active
$safe_mode_active = get_option( 'museder_restoreone_safe_mode', '' ) === '1';
$prev_plugins_count = 0;
if ( $safe_mode_active ) {
    $prev_plugins = get_option( 'museder_restoreone_prev_active_plugins', [] );
    $prev_plugins_count = is_array( $prev_plugins ) ? count( $prev_plugins ) : 0;
}
?>

<div class="wrap backup-lite-admin backup-lite-dashboard museder-restoreone-admin museder-restoreone-dashboard">
    <h1 class="backup-lite-page-title museder-restoreone-page-title">💾 <?php esc_html_e( 'Museder RestoreOne Dashboard', 'museder-restoreone' ); ?></h1>
    <p class="backup-lite-page-description museder-restoreone-page-description"><?php esc_html_e( 'Quick overview of your environment, schedules, and the latest backup health signals.', 'museder-restoreone' ); ?></p>

    <?php if ( $safe_mode_active ) : ?>
    <div class="notice notice-warning is-dismissible" id="museder-restoreone-safe-mode-notice" style="border-left-color: #ffb900; padding: 12px 20px; margin: 20px 0;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
            <div style="flex: 1; min-width: 300px;">
                <p style="margin: 0 0 8px 0; font-weight: 600;">
                    <span style="font-size: 20px; margin-right: 8px;">🛡️</span>
                    <?php esc_html_e( 'Safe Mode Active', 'museder-restoreone' ); ?>
                </p>
                <p style="margin: 0; color: var(--text-muted, #646970);">
                    <?php
                    printf(
                        /* translators: %d: Number of plugins recorded in the safe mode snapshot. */
                        esc_html__( 'RestoreOne saved a snapshot of %d active plugin(s) when safe mode was enabled after restore. Verify your site, then exit safe mode to clear this notice. Other plugins are not changed automatically.', 'museder-restoreone' ),
                        absint( $prev_plugins_count )
                    );
                    ?>
                </p>
            </div>
            <div>
                <button type="button" id="museder-restoreone-exit-safe-mode-btn" class="button button-primary" style="white-space: nowrap;">
                    <?php esc_html_e( 'Exit Safe Mode', 'museder-restoreone' ); ?>
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="backup-lite-dashboard-actions museder-restoreone-dashboard-actions">
        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=museder-restoreone-settings' ) ); ?>">⚙️ <?php esc_html_e( 'Settings', 'museder-restoreone' ); ?></a>
        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=museder-restoreone-schedules' ) ); ?>">🗓️ <?php esc_html_e( 'View Schedules', 'museder-restoreone' ); ?></a>
    </div>

    <div class="backup-lite-grid">
        <div class="backup-lite-card">
            <h2>⚙️ <?php esc_html_e( 'Environment Compatibility', 'museder-restoreone' ); ?></h2>
            <ul class="backup-lite-status-list">
                <li>
                    <span class="badge success">
                        <?php esc_html_e( 'Database backup/restore uses WordPress APIs (WP.org compliant)', 'museder-restoreone' ); ?>
                    </span>
                </li>
                <li>
                    <?php if ( ! empty( $status['ziparchive'] ) ) : ?>
                        <span class="badge success">
                            <?php esc_html_e( 'ZipArchive available', 'museder-restoreone' ); ?>
                        </span>
                    <?php else : ?>
                        <span class="badge pending">
                            <?php esc_html_e( 'ZipArchive missing (using PclZip)', 'museder-restoreone' ); ?>
                        </span>
                    <?php endif; ?>
                </li>
            </ul>
        </div>

        <div class="backup-lite-card">
            <h2>📦 <?php esc_html_e( 'Recent Backups', 'museder-restoreone' ); ?></h2>
            <?php if ( empty( $dashboard_recent_backups ) ) : ?>
                <p class="description"><?php esc_html_e( 'No backups created yet. Head to the Backups page to create your first snapshot.', 'museder-restoreone' ); ?></p>
            <?php else : ?>
                <ul class="backup-lite-list">
                    <?php foreach ( $dashboard_recent_backups as $museder_restoreone_item ) : ?>
                        <li>
                            <strong><?php echo esc_html( $museder_restoreone_item['name'] ); ?></strong>
                            <span>
                                <?php echo esc_html( $museder_restoreone_item['created'] ); ?>
                                <?php
                                $duration_seconds = isset( $museder_restoreone_item['duration_seconds'] ) && is_numeric( $museder_restoreone_item['duration_seconds'] ) ? (int) $museder_restoreone_item['duration_seconds'] : null;
                                if ( $duration_seconds !== null && $duration_seconds > 0 ) {
                                    echo ' (' . esc_html( museder_restoreone_format_duration( $duration_seconds ) ) . ')';
                                }
                                ?>
                                · <?php echo esc_html( $museder_restoreone_item['size_human'] ); ?>
                            </span>
                            <?php
                            $museder_restoreone_status_key  = strtolower( $museder_restoreone_item['status'] ?? 'pending' );
                            $museder_restoreone_status_map  = [
                                'success' => [ 'label' => __( 'Success', 'museder-restoreone' ), 'icon' => '✅', 'class' => 'success' ],
                                'failed'  => [ 'label' => __( 'Failed', 'museder-restoreone' ), 'icon' => '❌', 'class' => 'error' ],
                                'pending' => [ 'label' => __( 'Pending', 'museder-restoreone' ), 'icon' => '⏳', 'class' => 'pending' ],
                            ];
                            $museder_restoreone_status_item = $museder_restoreone_status_map[ $museder_restoreone_status_key ] ?? $museder_restoreone_status_map['pending'];
                            ?>
                            <span class="badge <?php echo esc_attr( $museder_restoreone_status_item['class'] ); ?>">
                                <?php echo esc_html( $museder_restoreone_status_item['icon'] . ' ' . $museder_restoreone_status_item['label'] ); ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <div class="backup-lite-card">
            <h2>🗓️ <?php esc_html_e( 'Schedule Overview', 'museder-restoreone' ); ?></h2>
            <?php if ( ! empty( $schedule_overview['next_run'] ) ) : ?>
                <p class="backup-lite-next-run">
                    <?php
                        printf(
                            /* translators: 1: Schedule title, 2: Schedule frequency, 3: Next run time. */
                            esc_html__( 'The next backup "%1$s" (%2$s) runs at %3$s.', 'museder-restoreone' ),
                            esc_html( $schedule_overview['title'] ),
                            esc_html( ucfirst( $schedule_overview['period'] ) ),
                            esc_html( $schedule_overview['next_run_human'] )
                        );
                    ?>
                </p>
                <p class="description">
                    <span id="bl-dashboard-countdown" data-next-run="<?php echo esc_attr( $schedule_overview['next_run'] ); ?>">
                        <?php echo esc_html( $schedule_overview['countdown'] ?? '' ); ?>
                    </span>
                </p>
                <?php if ( ! empty( $schedule_overview['last_run'] ) ) : ?>
                    <p class="description">
                        <?php
                        printf(
                            /* translators: %s: Date and time when the schedule last ran. */
                            esc_html__( 'Last run: %s', 'museder-restoreone' ),
                            esc_html( $schedule_overview['last_run'] )
                        );
                        ?>
                    </p>
                <?php endif; ?>
                <?php if ( ! empty( $schedule_overview['last_result'] ) ) : ?>
                    <p class="description">
                        <?php
                        $museder_restoreone_result_key  = strtolower( $schedule_overview['last_result'] );
                        $museder_restoreone_result_map  = [
                            'success' => '✅ ' . esc_html__( 'Success', 'museder-restoreone' ),
                            'failed'  => '❌ ' . esc_html__( 'Failed', 'museder-restoreone' ),
                            'pending' => '⏳ ' . esc_html__( 'Pending', 'museder-restoreone' ),
                        ];
                        ?>
                        <?php
                        printf(
                            /* translators: %s: Result of the most recent schedule run. */
                            esc_html__( 'Last result: %s', 'museder-restoreone' ),
                            esc_html( $museder_restoreone_result_map[ $museder_restoreone_result_key ] ?? ucfirst( $museder_restoreone_result_key ) )
                        );
                        ?>
                    </p>
                <?php endif; ?>
            <?php else : ?>
                <p class="description"><?php esc_html_e( 'No active schedules found. Create one to automate backups.', 'museder-restoreone' ); ?></p>
            <?php endif; ?>
        </div>

        <div class="backup-lite-card">
            <h2>📊 <?php esc_html_e( 'Activity (Last 7 Days)', 'museder-restoreone' ); ?></h2>
            <div class="backup-lite-chart-area">
                <canvas id="backup-lite-activity-chart" aria-label="<?php esc_attr_e( 'Backup success vs failure chart', 'museder-restoreone' ); ?>"></canvas>
                <?php // @plugin-check: escaped ?>
                <p id="bl-dashboard-chart-empty" class="backup-lite-chart-empty" <?php echo esc_attr( ( $chart_success + $chart_failed ) > 0 ? 'hidden' : '' ); ?>>
                    <?php esc_html_e( 'No activity recorded in the last 7 days.', 'museder-restoreone' ); ?>
                </p>
            </div>
        </div>

        <?php
        $museder_restoreone_is_pro_ai = function_exists( 'museder_is_pro_active' ) ? museder_is_pro_active() : false;
        $museder_restoreone_ai_reports = [];
        if ( class_exists( 'Museder_AI_Admin_Page' ) ) {
            $museder_restoreone_ai_reports = Museder_AI_Admin_Page::get_recent_reports( 5 );
        }
        $museder_restoreone_ai_latest       = ! empty( $museder_restoreone_ai_reports ) ? $museder_restoreone_ai_reports[0] : null;
        $museder_restoreone_ai_last_created = is_array( $museder_restoreone_ai_latest ) && isset( $museder_restoreone_ai_latest['created_at_gmt'] ) ? (string) $museder_restoreone_ai_latest['created_at_gmt'] : '';
        $museder_restoreone_ai_last_items   = [];
        if ( is_array( $museder_restoreone_ai_latest ) && isset( $museder_restoreone_ai_latest['report']['items'] ) && is_array( $museder_restoreone_ai_latest['report']['items'] ) ) {
            $museder_restoreone_ai_last_items = $museder_restoreone_ai_latest['report']['items'];
        }
        ?>
        <div class="backup-lite-card" id="backup-lite-ai-card">
            <h2>
                🤖 <?php esc_html_e( 'Offline readiness scan', 'museder-restoreone' ); ?>
            </h2>

            <p class="description" style="margin-top: 8px;">
                <?php esc_html_e( 'Local heuristics only — suggestions for your install. No remote model or third-party API is called.', 'museder-restoreone' ); ?>
            </p>

            <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-top: 10px;">
                <button type="button" class="button button-primary" id="backup-lite-ai-run-scan">
                    <?php esc_html_e( 'Run offline readiness scan', 'museder-restoreone' ); ?>
                </button>
                <span id="backup-lite-ai-status" class="description" aria-live="polite"></span>
            </div>

            <p class="description" style="margin-top: 10px;">
                <strong style="display:inline-block; margin-right:6px;"><?php esc_html_e( 'Last scan:', 'museder-restoreone' ); ?></strong>
                <span id="backup-lite-ai-last-scan">
                    <?php echo esc_html( $museder_restoreone_ai_last_created ? museder_restoreone_format_local_time( $museder_restoreone_ai_last_created ) : '—' ); ?>
                </span>
            </p>

            <div style="margin-top: 10px;" id="backup-lite-ai-latest-items-wrap" <?php echo empty( $museder_restoreone_ai_last_items ) ? 'hidden' : ''; // @plugin-check: escaped ?>>
                <strong><?php esc_html_e( 'Top local recommendations', 'museder-restoreone' ); ?></strong>
                <ul class="backup-lite-list" id="backup-lite-ai-latest-items" style="margin-top: 10px;">
                    <?php foreach ( array_slice( $museder_restoreone_ai_last_items, 0, 5 ) as $museder_restoreone_ai_item ) : ?>
                        <?php
                        $ai_severity = isset( $museder_restoreone_ai_item['severity'] ) ? strtolower( (string) $museder_restoreone_ai_item['severity'] ) : 'info';
                        $ai_title    = isset( $museder_restoreone_ai_item['title'] ) ? (string) $museder_restoreone_ai_item['title'] : '';
                        $ai_rec      = isset( $museder_restoreone_ai_item['recommendation'] ) ? (string) $museder_restoreone_ai_item['recommendation'] : '';
                        $ai_badge_class = 'success';
                        $ai_badge_label = __( 'Info', 'museder-restoreone' );
                        if ( 'high' === $ai_severity ) {
                            $ai_badge_class = 'error';
                            $ai_badge_label = __( 'High', 'museder-restoreone' );
                        } elseif ( 'medium' === $ai_severity ) {
                            $ai_badge_class = 'pending';
                            $ai_badge_label = __( 'Medium', 'museder-restoreone' );
                        }
                        ?>
                        <li>
                            <span class="badge <?php echo esc_attr( $ai_badge_class ); ?>"><?php echo esc_html( $ai_badge_label ); ?></span>
                            <?php if ( $ai_title ) : ?>
                                <strong><?php echo esc_html( $ai_title ); ?></strong>
                            <?php endif; ?>
                            <?php if ( $ai_rec ) : ?>
                                <span><?php echo esc_html( $ai_rec ); ?></span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div style="margin-top: 12px;">
                <strong><?php esc_html_e( 'Recent reports', 'museder-restoreone' ); ?></strong>
                <div id="backup-lite-ai-reports-container">
                <?php if ( empty( $museder_restoreone_ai_reports ) ) : ?>
                    <p class="description" id="backup-lite-ai-empty"><?php esc_html_e( 'No offline scan reports yet.', 'museder-restoreone' ); ?></p>
                <?php else : ?>
                    <ul class="backup-lite-list" id="backup-lite-ai-reports">
                        <?php foreach ( $museder_restoreone_ai_reports as $museder_restoreone_ai_entry ) : ?>
                            <?php
                            $museder_restoreone_ai_created = isset( $museder_restoreone_ai_entry['created_at_gmt'] ) ? (string) $museder_restoreone_ai_entry['created_at_gmt'] : '';
                            $museder_restoreone_ai_summary = isset( $museder_restoreone_ai_entry['report']['summary'] ) ? (string) $museder_restoreone_ai_entry['report']['summary'] : '';
                            $museder_restoreone_ai_items   = isset( $museder_restoreone_ai_entry['report']['items'] ) && is_array( $museder_restoreone_ai_entry['report']['items'] ) ? $museder_restoreone_ai_entry['report']['items'] : [];
                            ?>
                            <li>
                                    <strong><?php echo esc_html( $museder_restoreone_ai_created ? museder_restoreone_format_local_time( $museder_restoreone_ai_created ) : '' ); ?></strong>
                                <?php if ( $museder_restoreone_ai_summary ) : ?>
                                    <span><?php echo esc_html( $museder_restoreone_ai_summary ); ?></span>
                                <?php endif; ?>
                                <?php if ( ! empty( $museder_restoreone_ai_items ) ) : ?>
                                    <details style="margin-top: 6px;">
                                        <summary><?php esc_html_e( 'View details', 'museder-restoreone' ); ?></summary>
                                        <ul style="margin: 8px 0 0 18px;">
                                            <?php foreach ( array_slice( $museder_restoreone_ai_items, 0, 5 ) as $museder_restoreone_ai_item ) : ?>
                                                <?php
                                                    $ai_severity = isset( $museder_restoreone_ai_item['severity'] ) ? strtolower( (string) $museder_restoreone_ai_item['severity'] ) : 'info';
                                                    $ai_title    = isset( $museder_restoreone_ai_item['title'] ) ? (string) $museder_restoreone_ai_item['title'] : '';
                                                    $ai_rec      = isset( $museder_restoreone_ai_item['recommendation'] ) ? (string) $museder_restoreone_ai_item['recommendation'] : '';
                                                    $ai_badge_class = 'success';
                                                    $ai_badge_label = __( 'Info', 'museder-restoreone' );
                                                    if ( 'high' === $ai_severity ) {
                                                        $ai_badge_class = 'error';
                                                        $ai_badge_label = __( 'High', 'museder-restoreone' );
                                                    } elseif ( 'medium' === $ai_severity ) {
                                                        $ai_badge_class = 'pending';
                                                        $ai_badge_label = __( 'Medium', 'museder-restoreone' );
                                                    }
                                                ?>
                                                <li>
                                                        <span class="badge <?php echo esc_attr( $ai_badge_class ); ?>"><?php echo esc_html( $ai_badge_label ); ?></span>
                                                        <?php if ( $ai_title ) : ?>
                                                    <strong><?php echo esc_html( $ai_title ); ?></strong>
                                                        <?php endif; ?>
                                                    <?php if ( $ai_rec ) : ?>
                                                        <span> — <?php echo esc_html( $ai_rec ); ?></span>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </details>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                </div>
            </div>

        </div>

        <div class="backup-lite-card">
            <h2>🔥 <?php esc_html_e( 'Latest Logs', 'museder-restoreone' ); ?></h2>
            <?php if ( empty( $recent_logs ) ) : ?>
                <p class="description"><?php esc_html_e( 'No log entries yet.', 'museder-restoreone' ); ?></p>
            <?php else : ?>
                <ul class="backup-lite-list">
                    <?php foreach ( $recent_logs as $log ) : ?>
                        <li>
                            <strong><?php echo esc_html( $log['name'] ); ?></strong>
                            <span><?php echo esc_html( $log['modified'] ?? '' ); ?> · <?php echo esc_html( $log['size'] ?? '' ); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

    </div>
</div>

